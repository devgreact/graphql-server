# GraphQL

- https://graphql.org/
- https://graphql-kr.github.io/

## Apollo Server

- Apollo Client 까지 제공합니다.
- React, Vue, Angula, Svelet ...
- 백엔드 API 구축

## Apollo Server 프로젝트 생성

- `npm init`
- package.json 추가

```json
 "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "start": "nodemon index.js"
  },
```

## 필요 모듈 설치

- `npm i convert-csv-to-json`
- `npm i graphql apollo-server`

## 필요 소스 작성

- /data 폴더 / todos.csv

```csv
id,title,completed,date,weather
1,공부중입니다.,false,2023-04-01,1
2,리액트공부,false,2023-04-02,2
3,html 공부,true,2023-04-03,2
4,css 공부,true,2023-04-04,3
5,js 공부,false,2023-04-05,3
6,git공부,true,2023-04-06,5
7,서버공부,true,2023-04-07,4
```

- index.js 파일생성

```js
const database = require("./database");
console.log(database);
```

- index.js 테스트 후 내용추가

```js
const database = require("./database");
const { ApolloServer, gql } = require("apollo-server");
const typeDefs = gql`
  type Query {
    todos: [Todo]
  }
  type Todo {
    id: Int
    title: String
    date: String
    complete: Boolean
    weather: Int
  }
`;
const resolvers = {
  Query: {
    todos: () => database.todos,
  },
};
const server = new ApolloServer({ typeDefs, resolvers });
server.listen().then(({ url }) => {
  console.log(`🚀  Server ready at ${url}`);
});
```

- database.js 파일 생성

```js
const csvToJson = require("convert-csv-to-json");

const database = {
  todos: [],
};
Object.keys(database).forEach((key) => {
  database[key] = [...database[key], ...csvToJson.fieldDelimiter(",").getJsonFromCsv(`./data/${key}.csv`)];
  if (database[key].length > 0) {
    const firstItem = database[key][0];
    Object.keys(firstItem).forEach((itemKey) => {
      if (
        database[key].every((item) => {
          return /^-?\d+$/.test(item[itemKey]);
        })
      ) {
        database[key].forEach((item) => {
          item[itemKey] = Number(item[itemKey]);
        });
      }
    });
  }
});

module.exports = database;
```

- 테스트
  `npm start`

- 쿼리 테스트

```json
query {
  todos {
    title,
    weather
  }
}
```
