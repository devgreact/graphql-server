const database = require("./database");
const { ApolloServer, gql } = require("apollo-server");

// js 로 만들어진 서버이므로 js 문법을 따름
// gpl 템플릿 문법 : Styled 또는 백틱 문법
// type 은 TS 처럼 생각하면 됩니다.
// Graph QL 데이터 종류 명세서
// 타입 생성시 gql 을 사용한다.
const typeDefs = gql`
  type Query {
    todos: [Todo]
  }
  type Todo {
    id: Int
    title: String
    date: String
    complete: Boolean
    weather: Int
  }
`;
// 액션들을 함수로 지정한다.
// 요청이 들어오면 데이터를 반환, 입력, 수정, 삭제
// JS 의 함수 형태로 정의하시면 됩니다.
const resolvers = {
  Query: {
    todos: () => database.todos,
  },
};
//
const server = new ApolloServer({ typeDefs, resolvers });
server.listen().then(({ url }) => {
  console.log(`🚀  Server ready at ${url}`);
});
